#!/usr/bin/env python3
"""
Build a workbook that lets anyone re-derive the report's headline numbers in
Excel, from the client's raw readings, without running or trusting any Python.

    python export_verification_xlsx.py jobs/<client>.json

Every number on the "Verification" sheet exists twice:
  - what the report printed (typed in, marked blue)
  - what an Excel formula computes from column A and B of the raw data
If the two columns don't match, the report is wrong. That is the whole point.

The closed/occupied flag is recomputed in Excel too (WEEKDAY / HOUR / holiday
lookup), so not even the split is taken on trust.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

sys.path.insert(0, str(Path(__file__).parent))
from engine.checks import Schedule, analyse, reconcile
from engine.ingest import load_meter_csv

ARIAL = "Arial"
BLUE = Font(name=ARIAL, size=10, color="0000FF")          # typed in from the report
BLACK = Font(name=ARIAL, size=10)                          # Excel formula
BOLD = Font(name=ARIAL, size=10, bold=True)
H1 = Font(name=ARIAL, size=14, bold=True)
H2 = Font(name=ARIAL, size=11, bold=True)
MUTED = Font(name=ARIAL, size=9, color="666666")
HEAD_FILL = PatternFill("solid", fgColor="EEEEEA")
OK_FILL = PatternFill("solid", fgColor="E4F2E9")
THIN = Side(style="thin", color="D5D5D0")
BOX = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)


def build(job_path: str) -> int:
    job = json.loads(Path(job_path).read_text(encoding="utf-8"))
    df, q = load_meter_csv(job["csv"], timezone=job.get("timezone", "Europe/Berlin"),
                           unit=job.get("unit", "kwh"),
                           timestamp_col=job.get("timestamp_col"),
                           value_col=job.get("value_col"))
    sch = Schedule(open_hour=job.get("open_hour", 8), close_hour=job.get("close_hour", 18),
                   workdays=tuple(job.get("workdays", [0, 1, 2, 3, 4])),
                   holidays=job.get("holidays", []),
                   shutdowns=[tuple(s) for s in job.get("shutdowns", [])])
    price = job["price_eur_kwh"]
    res = analyse(df, sch, q.interval_minutes, price, job.get("area_m2"))
    ih = q.interval_minutes / 60.0

    wb = Workbook()

    # ─────────────────────────── sheet 1: instructions ──────────────────────
    s = wb.active
    s.title = "How to check"
    s.column_dimensions["A"].width = 100
    lines = [
        (f"Checking the out-of-hours report — {job['building']}", H1),
        ("", None),
        ("This workbook re-derives the report's headline numbers from the raw meter "
         "readings using ordinary Excel formulas. No Python runs here.", BLACK),
        ("", None),
        ("What to do:", H2),
        ("1. Open the 'Verification' sheet.", BLACK),
        ("2. The BLUE column is what the report printed. It is typed in — nothing "
         "computes it.", BLACK),
        ("3. The BLACK column is an Excel formula reading the 'Meter data' sheet. "
         "Click any cell to see the formula.", BLACK),
        ("4. The 'Difference' column must be zero (or a rounding crumb). If it is "
         "not, the report is wrong — do not send it.", BLACK),
        ("", None),
        ("Where the numbers come from:", H2),
        ("'Meter data' holds only what the client sent: column A the timestamp, "
         "column B the kWh. Columns D to G are Excel formulas that work out the "
         "weekday, the hour, whether the building was closed, and the kW.", BLACK),
        ("The closed/occupied split is therefore recomputed here too — the report's "
         "own version of it is not used anywhere in this file.", BLACK),
        ("", None),
        ("The one check you can do without this file at all:", H2),
        ("Open the client's CSV in Excel, select the whole kWh column, and read the "
         "sum in the status bar. It must equal 'Total energy in file' on the last "
         "page of the report.", BLACK),
        ("", None),
        ("Note on the median:", H2),
        ("The report calls the typical closed-period load a median. Excel's MEDIAN "
         "is used here on the same set of readings, so the two should agree exactly.", MUTED),
    ]
    for i, (txt, font) in enumerate(lines, start=1):
        c = s.cell(row=i, column=1, value=txt)
        if font:
            c.font = font
        c.alignment = Alignment(wrap_text=True, vertical="top")
        if font in (BLACK, MUTED):
            s.row_dimensions[i].height = 30

    # ─────────────────────────── sheet 2: meter data ────────────────────────
    d = wb.create_sheet("Meter data")
    heads = ["Timestamp (from client file)", "kWh (from client file)", "",
             "Weekday 1=Mon", "Hour", "Closed? 1=yes", "kW", "kWh if closed"]
    for j, h in enumerate(heads, start=1):
        c = d.cell(row=1, column=j, value=h)
        c.font = BOLD; c.fill = HEAD_FILL; c.border = BOX
        c.alignment = Alignment(wrap_text=True, vertical="center")
        d.column_dimensions[get_column_letter(j)].width = 22 if j <= 2 else 13
    d.freeze_panes = "A2"

    ts = df.index.tz_localize(None)
    kwh = df["kwh"].to_numpy()
    n = len(ts)

    # holidays + shutdown dates go in a lookup block off to the right
    hol_dates = sorted({pd.Timestamp(x).date() for x in sch.holidays} |
                       {d_.date() for a, b in sch.shutdowns
                        for d_ in pd.date_range(a, b)})
    d.cell(row=1, column=11, value="Closed dates supplied by the client").font = BOLD
    for i, hd in enumerate(hol_dates, start=2):
        d.cell(row=i, column=11, value=pd.Timestamp(hd)).number_format = "yyyy-mm-dd"
    d.column_dimensions["K"].width = 20
    hol_ref = f"$K$2:$K${max(len(hol_dates)+1, 2)}"

    wd_max = max(sch.workdays) + 1          # WEEKDAY(...,2): Mon=1
    for i in range(n):
        r = i + 2
        d.cell(row=r, column=1, value=ts[i].to_pydatetime()).number_format = "yyyy-mm-dd hh:mm"
        d.cell(row=r, column=2, value=float(kwh[i])).number_format = "0.0000"
        d.cell(row=r, column=4, value=f"=WEEKDAY(A{r},2)")
        d.cell(row=r, column=5, value=f"=HOUR(A{r})+MINUTE(A{r})/60")
        d.cell(row=r, column=6, value=(
            f"=IF(OR(D{r}>{wd_max},E{r}<{sch.open_hour},E{r}>={sch.close_hour},"
            f"COUNTIF({hol_ref},INT(A{r}))>0),1,0)"))
        d.cell(row=r, column=7, value=f"=B{r}/{ih}").number_format = "0.00"
        d.cell(row=r, column=8, value=f'=IF(F{r}=1,G{r},"")').number_format = "0.00"

    # ─────────────────────────── sheet 3: verification ──────────────────────
    v = wb.create_sheet("Verification")
    wb.move_sheet("Verification", offset=-1)
    v.column_dimensions["A"].width = 46
    for col in "BCD":
        v.column_dimensions[col].width = 19
    v.column_dimensions["E"].width = 52

    v["A1"] = "Verification"; v["A1"].font = H1
    v["A2"] = ("Blue = typed in from the report.  Black = computed here by Excel "
               "from the raw readings.  Every difference must be zero.")
    v["A2"].font = MUTED
    hdr = ["What", "Report says", "Excel says", "Difference", "The Excel formula, in words"]
    for j, h in enumerate(hdr, start=1):
        c = v.cell(row=4, column=j, value=h)
        c.font = BOLD; c.fill = HEAD_FILL; c.border = BOX

    last = n + 1
    B, F, G, H = (f"'Meter data'!$B$2:$B${last}", f"'Meter data'!$F$2:$F${last}",
                  f"'Meter data'!$G$2:$G${last}", f"'Meter data'!$H$2:$H${last}")

    rows = [
        ("Readings used", q.rows_used, f"=COUNT({B})", "0",
         "COUNT of the kWh column"),
        ("Total energy (kWh)", res["total_kwh"], f"=SUM({B})", "#,##0.00",
         "SUM of the kWh column"),
        ("Energy while closed (kWh)", res["closed_kwh"],
         f"=SUMIF({F},1,{B})", "#,##0.00",
         "SUM of kWh where the closed flag is 1"),
        ("Energy while occupied (kWh)", res["open_kwh"],
         f"=SUMIF({F},0,{B})", "#,##0.00",
         "SUM of kWh where the closed flag is 0"),
        ("Closed share of the year (%)", res["closed_share_pct"] / 100,
         f"=SUMIF({F},1,{B})/SUM({B})", "0.0%",
         "closed kWh divided by total kWh"),
        ("Hours closed", res["closed_hours"], f"=COUNTIF({F},1)*{ih}", "#,##0.0",
         f"count of closed readings x {ih} h per reading"),
        ("Cost of closed-period energy", res["closed_kwh"] * price,
         f"=SUMIF({F},1,{B})*{price}", "#,##0",
         f"closed kWh x {price} per kWh"),
        ("Worth of 1 kW switched off, per year", res["eur_per_kw_removed"],
         f"=COUNTIF({F},1)*{ih}*{price}", "#,##0",
         "hours closed x tariff"),
        ("Typical load while closed (kW)", res["typical_closed_kw"],
         f"=MEDIAN({H})", "0.00",
         "MEDIAN of the kW readings that fall in closed hours"),
        ("Average load while occupied (kW)", res["mean_open_kw"],
         f"=AVERAGEIF({F},0,{G})", "0.00",
         "AVERAGE of kW where the closed flag is 0"),
        ("Peak load (kW)", res["peak_kw"], f"=MAX({G})", "0.00",
         "MAX of the kW column"),
    ]
    for i, (label, reported, formula, fmt, words) in enumerate(rows):
        r = 5 + i
        v.cell(row=r, column=1, value=label).font = BLACK
        c = v.cell(row=r, column=2, value=float(reported)); c.font = BLUE; c.number_format = fmt
        c = v.cell(row=r, column=3, value=formula); c.font = BLACK; c.number_format = fmt
        c = v.cell(row=r, column=4, value=f"=C{r}-B{r}"); c.font = BLACK
        c.number_format = "0.000000"
        v.cell(row=r, column=5, value=words).font = MUTED
        for j in range(1, 6):
            v.cell(row=r, column=j).border = BOX

    end = 5 + len(rows) - 1
    r = end + 2
    v.cell(row=r, column=1, value="Largest difference anywhere above").font = BOLD
    # ABS over a range needs array entry; MAX/-MIN is the plain equivalent
    c = v.cell(row=r, column=3, value=f"=MAX(MAX(D5:D{end}),-MIN(D5:D{end}))")
    c.font = BOLD; c.number_format = "0.000000"; c.fill = OK_FILL
    v.cell(row=r, column=5,
           value="Anything other than a rounding crumb means do not send the report."
           ).font = MUTED

    r += 1
    v.cell(row=r, column=1, value="VERDICT").font = H2
    c = v.cell(row=r, column=2,
               value=f'=IF(C{r-1}<0.01,"ALL {len(rows)} NUMBERS MATCH - report is safe to send",'
                     f'"MISMATCH - do NOT send this report")')
    c.font = Font(name=ARIAL, size=12, bold=True)
    c.fill = OK_FILL
    c.alignment = Alignment(horizontal="left")
    v.merge_cells(start_row=r, start_column=2, end_row=r, end_column=5)
    v.row_dimensions[r].height = 26

    r += 2
    v.cell(row=r, column=1, value="Settings these formulas use").font = H2
    for lbl, val in [("Operating hours", f"{sch.open_hour:02.0f}:00 to {sch.close_hour:02.0f}:00"),
                     ("Working days", "Mon-Fri" if wd_max == 5 else f"weekday <= {wd_max}"),
                     ("Reading interval", f"{q.interval_minutes} minutes"),
                     ("Tariff", f"{price} per kWh"),
                     ("Closed dates supplied", f"{len(hol_dates)} dates, listed on 'Meter data' column K"),
                     ("Timestamp handling", q.timestamp_mode)]:
        r += 1
        v.cell(row=r, column=1, value=lbl).font = BLACK
        c = v.cell(row=r, column=2, value=val); c.font = BLUE
        c.alignment = Alignment(wrap_text=True)

    out = Path(job.get("out", "out/report.html")).parent / "verification.xlsx"
    out.parent.mkdir(parents=True, exist_ok=True)
    wb.save(out)
    print(f"  {out}  ({n:,} readings, {len(rows)} numbers cross-checked)")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(__doc__)
        raise SystemExit(2)
    raise SystemExit(build(sys.argv[1]))
