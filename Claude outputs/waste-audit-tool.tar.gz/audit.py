#!/usr/bin/env python3
"""
Out-of-hours energy review — one command per client.

    python audit.py jobs/acme.json              # the full paid report
    python audit.py jobs/acme.json --teaser     # the free one-page sample

The job file is the ONLY thing that changes between clients. Everything else
is identical every time, which is what makes the output comparable and the
method defensible.

The report is NOT written if any reconciliation check fails.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from engine.checks import Schedule, analyse, reconcile
from engine.ingest import load_meter_csv
from engine.report import render, render_teaser


def run(job_path: str, teaser: bool = False) -> int:
    job = json.loads(Path(job_path).read_text(encoding="utf-8"))

    df, q = load_meter_csv(
        job["csv"],
        timezone=job.get("timezone", "Europe/Berlin"),
        unit=job.get("unit", "kwh"),
        timestamp_col=job.get("timestamp_col"),
        value_col=job.get("value_col"),
    )

    sch = Schedule(
        open_hour=job.get("open_hour", 8),
        close_hour=job.get("close_hour", 18),
        workdays=tuple(job.get("workdays", [0, 1, 2, 3, 4])),
        holidays=job.get("holidays", []),
        shutdowns=[tuple(s) for s in job.get("shutdowns", [])],
    )

    res = analyse(df, sch, q.interval_minutes,
                  price_eur_kwh=job["price_eur_kwh"],
                  area_m2=job.get("area_m2"))

    checks = reconcile(res, q, q.raw_sum)

    print(f"\n  {job['building']} — {q.first_ts:%Y-%m-%d} to {q.last_ts:%Y-%m-%d}")
    print(f"  {q.rows_used:,} readings at {q.interval_minutes} min, "
          f"{q.coverage_pct:.2f}% coverage\n")
    for name, ok, detail in checks:
        print(f"  {'PASS' if ok else 'FAIL'}  {name}\n        {detail}")

    failed = [c for c in checks if not c[1]]
    if failed:
        print(f"\n  {len(failed)} CHECK(S) FAILED — report not written.")
        print("  Fix the data or the job file and re-run.\n")
        return 1

    meta = {
        "building": job["building"],
        "client": job.get("client", job["building"]),
        "author": job.get("author", ""),
        "schedule": sch,
    }
    out = Path(job.get("out", "out/report.html"))
    if teaser:
        out = out.with_name(out.stem + "_teaser" + out.suffix)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(render_teaser(res, q, meta) if teaser
                   else render(res, q, checks, meta), encoding="utf-8")

    print(f"\n  All checks passed.")
    print(f"  Closed-period energy : {res['closed_kwh']:,.0f} kWh "
          f"({res['closed_share_pct']:.1f}% of total) = "
          f"EUR {res['closed_kwh']*res['price_eur_kwh']:,.0f}")
    print(f"  Value of 1 kW saved  : EUR {res['eur_per_kw_removed']:,.0f}/year")
    print(f"  Report               : {out}\n")
    return 0


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if len(args) != 1:
        print(__doc__)
        raise SystemExit(2)
    raise SystemExit(run(args[0], teaser="--teaser" in sys.argv))
