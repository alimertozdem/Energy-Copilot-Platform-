"""
Synthetic office building with DELIBERATELY PLANTED waste.

Purpose: this is the verification fixture. We know the correct answer before
running the audit, so the audit's output can be checked against ground truth.

Planted facts (ground truth, written to fixture_truth.json):
  - Operating hours     : Mon-Fri 08:00-18:00
  - True occupied load  : ~55 kW average during operating hours
  - True night floor    : 18 kW  <-- this is the waste. A well-run building of
                          this size should sit near 6 kW overnight.
  - Weekend behaviour   : same 18 kW floor all weekend (nothing switches off)
  - HVAC pre-start      : load ramps at 05:30, not 08:00 (2.5h early start)
  - Christmas shutdown  : Dec 24 - Jan 1 building closed, but floor stays 18 kW
  - Data quality        : 3 gaps planted + 1 duplicate timestamp + DST days
"""
import json
import numpy as np
import pandas as pd

RNG = np.random.default_rng(20260913)

START = pd.Timestamp("2025-01-01 00:00", tz="Europe/Berlin")
END = pd.Timestamp("2026-01-01 00:00", tz="Europe/Berlin")
FREQ = "15min"

# ---- ground truth knobs -----------------------------------------------------
NIGHT_FLOOR_KW = 18.0          # planted waste: true overnight baseload
OCCUPIED_KW = 55.0             # average load during real occupancy
RAMP_START_HOUR = 5.5          # HVAC starts 05:30, stated opening is 08:00
RAMP_END_HOUR = 19.0           # load decays back to floor by 19:00
STATED_OPEN, STATED_CLOSE = 8, 18
AREA_M2 = 4200
PRICE_EUR_KWH = 0.29

SHUTDOWN = (pd.Timestamp("2025-12-24").date(), pd.Timestamp("2026-01-01").date())
HOLIDAYS = [  # German public holidays 2025 (Berlin) - building should be empty
    "2025-01-01", "2025-03-08", "2025-04-18", "2025-04-21", "2025-05-01",
    "2025-05-29", "2025-06-09", "2025-10-03", "2025-12-25", "2025-12-26",
]
HOLIDAY_DATES = {pd.Timestamp(d).date() for d in HOLIDAYS}


def occupied_mask(idx: pd.DatetimeIndex) -> np.ndarray:
    """True when the building is genuinely in use (per stated schedule)."""
    weekday = idx.dayofweek < 5
    in_hours = (idx.hour >= STATED_OPEN) & (idx.hour < STATED_CLOSE)
    not_holiday = ~np.isin(np.array([d.date() for d in idx]), list(HOLIDAY_DATES))
    in_shutdown = np.array(
        [SHUTDOWN[0] <= d.date() <= SHUTDOWN[1] for d in idx]
    )
    return weekday & in_hours & not_holiday & ~in_shutdown


def build() -> pd.DataFrame:
    idx = pd.date_range(START, END, freq=FREQ, inclusive="left", tz="Europe/Berlin")
    hour = idx.hour + idx.minute / 60.0
    occ = occupied_mask(idx)

    # Baseload: always present, never switched off. This IS the waste.
    kw = np.full(len(idx), NIGHT_FLOOR_KW)

    # HVAC/lighting ramp on working days (incl. the too-early 05:30 start)
    workday = (idx.dayofweek < 5)
    workday &= ~np.isin(np.array([d.date() for d in idx]), list(HOLIDAY_DATES))
    workday &= ~np.array([SHUTDOWN[0] <= d.date() <= SHUTDOWN[1] for d in idx])

    ramp = np.zeros(len(idx))
    rising = (hour >= RAMP_START_HOUR) & (hour < STATED_OPEN)
    ramp[rising] = (hour[rising] - RAMP_START_HOUR) / (STATED_OPEN - RAMP_START_HOUR)
    ramp[occ] = 1.0
    falling = (hour >= STATED_CLOSE) & (hour < RAMP_END_HOUR)
    ramp[falling] = 1.0 - (hour[falling] - STATED_CLOSE) / (RAMP_END_HOUR - STATED_CLOSE)
    ramp = np.where(workday, ramp, 0.0)

    kw = kw + ramp * (OCCUPIED_KW - NIGHT_FLOOR_KW)

    # Seasonal HVAC swing (colder/hotter -> more load), applied to the ramp part
    doy = idx.dayofyear.to_numpy()
    season = 1.0 + 0.22 * np.cos(2 * np.pi * (doy - 20) / 365.0)
    kw = NIGHT_FLOOR_KW + (kw - NIGHT_FLOOR_KW) * season

    # Measurement noise
    kw = kw * RNG.normal(1.0, 0.035, len(idx))
    kw = np.clip(kw, 2.0, None)

    kwh = kw * 0.25  # 15-minute interval

    df = pd.DataFrame({"timestamp": idx, "kwh": np.round(kwh, 4)})

    # ---- planted data-quality defects --------------------------------------
    # 3 gaps (meter outages)
    gaps = [
        ("2025-03-11 02:00", "2025-03-11 09:00"),
        ("2025-07-02 13:15", "2025-07-02 16:00"),
        ("2025-11-19 00:00", "2025-11-20 00:00"),
    ]
    drop = np.zeros(len(df), dtype=bool)
    for a, b in gaps:
        a = pd.Timestamp(a, tz="Europe/Berlin")
        b = pd.Timestamp(b, tz="Europe/Berlin")
        drop |= (df["timestamp"] >= a) & (df["timestamp"] < b)
    n_dropped = int(drop.sum())
    df = df.loc[~drop].reset_index(drop=True)

    # 1 duplicated timestamp
    dup_row = df.iloc[5000:5001].copy()
    df = pd.concat([df, dup_row], ignore_index=True).sort_values("timestamp")
    df = df.reset_index(drop=True)

    truth = {
        "night_floor_kw": NIGHT_FLOOR_KW,
        "occupied_kw_nominal": OCCUPIED_KW,
        "actual_ramp_start_hour": RAMP_START_HOUR,
        "stated_open_hour": STATED_OPEN,
        "stated_close_hour": STATED_CLOSE,
        "area_m2": AREA_M2,
        "price_eur_kwh": PRICE_EUR_KWH,
        "planted_gaps": len(gaps),
        "planted_missing_intervals": n_dropped,
        "planted_duplicate_rows": 1,
        "total_kwh": float(df["kwh"].sum()),
        "rows": int(len(df)),
    }
    return df, truth


if __name__ == "__main__":
    df, truth = build()
    # deliberately export in a messy-but-realistic shape (what a real export looks like)
    out = df.copy()
    out["timestamp"] = out["timestamp"].dt.strftime("%Y-%m-%d %H:%M:%S%z")
    out.columns = ["Zeitstempel", "Verbrauch_kWh"]   # German column names, on purpose
    out.to_csv("/home/claude/waste-audit/testdata/fixture_meter_export.csv",
               index=False, sep=";", decimal=",")     # German CSV conventions
    with open("/home/claude/waste-audit/testdata/fixture_truth.json", "w") as f:
        json.dump(truth, f, indent=2)
    print(json.dumps(truth, indent=2))
