#!/usr/bin/env python3
"""
Export the SAME analysis as a Power BI model.

    python export_powerbi.py jobs/<client>.json

Why this exists: the PDF report and the dashboard must never disagree. Both are
produced by engine/checks.py, so the closed/occupied split, the tariff and the
demonstrated floor are computed once and exported — Power BI only aggregates.
No business logic is re-implemented in DAX.

Writes to <out folder>/powerbi/:
    fact_readings.csv   one row per interval, already flagged
    dim_date.csv        calendar with day types
    dim_hour.csv        hour of day with period bands
    measures.dax        the DAX to paste in
    BUILD.md            what to click, in order
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).parent))
from engine.checks import Schedule, _closed_mask, analyse, reconcile
from engine.ingest import load_meter_csv

MEASURES = """// ─────────────────────────────────────────────────────────────
// Out-of-hours energy review — measures
// The closed/occupied split is already flagged in fact_readings,
// so these measures only aggregate. Keep it that way: any logic
// added here can drift away from the PDF report.
// ─────────────────────────────────────────────────────────────

Total kWh = SUM ( fact_readings[kwh] )

Closed kWh =
CALCULATE ( [Total kWh], fact_readings[is_closed] = TRUE () )

Occupied kWh =
CALCULATE ( [Total kWh], fact_readings[is_closed] = FALSE () )

Closed share % =
DIVIDE ( [Closed kWh], [Total kWh] )

Tariff = MAX ( fact_readings[price_eur_kwh] )

Closed cost = [Closed kWh] * [Tariff]

Total cost = [Total kWh] * [Tariff]

// Average power over whatever period is in filter context.
// Uses the interval length carried on the rows, so it stays correct
// for 15-minute and hourly data alike.
Interval hours = MAX ( fact_readings[interval_hours] )

Avg kW = DIVIDE ( [Total kWh], COUNTROWS ( fact_readings ) * [Interval hours] )

Avg kW closed =
CALCULATE ( [Avg kW], fact_readings[is_closed] = TRUE () )

Avg kW occupied =
CALCULATE ( [Avg kW], fact_readings[is_closed] = FALSE () )

Closed vs occupied load % =
DIVIDE ( [Avg kW closed], [Avg kW occupied] )

Peak kW = MAX ( fact_readings[kw] )

// Hours the building was closed in the current filter context
Closed hours =
CALCULATE (
    COUNTROWS ( fact_readings ) * [Interval hours],
    fact_readings[is_closed] = TRUE ()
)

// The conversion rate the report leads with: what one kilowatt is worth.
// No target is assumed — the user picks the reduction.
EUR per kW removed = [Closed hours] * [Tariff]

// Scenario: drop the closed-period load by the % on the what-if slicer.
// Create the parameter with Modeling > New parameter > Numeric range 0-50, step 5.
Scenario saving EUR =
VAR Pct = SELECTEDVALUE ( 'Reduction %'[Reduction %], 0 ) / 100
RETURN [Avg kW closed] * Pct * [Closed hours] * [Tariff]

Scenario saving kWh =
VAR Pct = SELECTEDVALUE ( 'Reduction %'[Reduction %], 0 ) / 100
RETURN [Avg kW closed] * Pct * [Closed hours]
"""

BUILD = """# Building the dashboard

Everything here is import-only. No gateway, no Fabric capacity, no scheduled
refresh — the client's file is the source.

## 1. Load

Power BI Desktop → Get data → Text/CSV → load all three files:
`fact_readings.csv`, `dim_date.csv`, `dim_hour.csv`.

Check the types on import: `date` must be Date, `timestamp` Date/time,
`is_closed` and `is_holiday` True/False, `kwh` and `kw` Decimal number.

## 2. Relationships

Model view → drag:

- `dim_date[date]`  1 → *  `fact_readings[date]`
- `dim_hour[hour]`  1 → *  `fact_readings[hour]`

Both single-direction, both Many-to-one from the fact. Mark `dim_date` as a
date table (right-click → Mark as date table → `date`).

## 3. Measures

New measure → paste each block from `measures.dax`. They are ordered so nothing
references a measure that does not exist yet.

## 4. Pages

**Page 1 — the headline**
- Card: `Closed kWh`, titled "Electricity used while closed"
- Card: `Closed cost`
- Card: `Closed share %` (format as %)
- Card: `EUR per kW removed`, titled "Worth per kW switched off, per year"
- Line chart: axis `dim_hour[hour]`, values `Avg kW`, legend `dim_date[day_type]`
  → this is the chart that sells the job; it shows the closed-day line
  following a working-day shape
- Matrix: rows `dim_hour[hour]`, columns `dim_date[month_name]`, values `Avg kW`,
  conditional formatting → background colour scale. This is the carpet plot.

**Page 2 — what a reduction is worth**
- Modeling → New parameter → Numeric range, name `Reduction %`, 0 to 50, step 5
- Card: `Scenario saving EUR`, with the slicer on the page
- Table: `dim_date[date]`, `Closed kWh`, `Closed cost`, sorted descending

**Page 3 — the data**
- Table: row count, coverage, interval length, tariff (from `run_summary.csv`)
- This page is why the client believes the other two.

## 5. Sharing it

Publish → the client needs a Power BI Pro licence to open a shared report, and
so do you. If they do not have one, build it in **their** tenant instead, or
send the PDF report. Do not put a paying client's dashboard on a trial capacity.
"""


def run(job_path: str) -> int:
    job = json.loads(Path(job_path).read_text(encoding="utf-8"))

    df, q = load_meter_csv(job["csv"], timezone=job.get("timezone", "Europe/Berlin"),
                           unit=job.get("unit", "kwh"),
                           timestamp_col=job.get("timestamp_col"),
                           value_col=job.get("value_col"))
    sch = Schedule(open_hour=job.get("open_hour", 8),
                   close_hour=job.get("close_hour", 18),
                   workdays=tuple(job.get("workdays", [0, 1, 2, 3, 4])),
                   holidays=job.get("holidays", []),
                   shutdowns=[tuple(s) for s in job.get("shutdowns", [])])
    price = job["price_eur_kwh"]

    res = analyse(df, sch, q.interval_minutes, price, job.get("area_m2"))
    checks = reconcile(res, q, q.raw_sum)
    failed = [c for c in checks if not c[1]]
    if failed:
        print(f"  {len(failed)} check(s) failed — refusing to export a model "
              "the PDF report would not be issued from:")
        for n, _, d in failed:
            print(f"    FAIL {n}\n         {d}")
        return 1

    h = q.interval_minutes / 60.0
    closed = _closed_mask(df.index, sch)
    hol = {pd.Timestamp(x).date() for x in sch.holidays}

    fact = pd.DataFrame({
        "timestamp": df.index.tz_localize(None),
        "date": df.index.tz_localize(None).normalize(),
        "hour": df.index.hour,
        "kwh": df["kwh"].to_numpy(),
        "kw": (df["kwh"] / h).to_numpy(),
        "is_closed": closed,
        "interval_hours": h,
        "price_eur_kwh": price,
    })

    d = pd.DatetimeIndex(sorted(fact["date"].unique()))
    dim_date = pd.DataFrame({
        "date": d, "year": d.year, "month": d.month,
        "month_name": d.strftime("%b"), "weekday": d.dayofweek,
        "day_name": d.day_name(),
        "is_weekend": ~d.dayofweek.isin(sch.workdays),
        "is_holiday": [x.date() in hol for x in d],
    })
    dim_date["day_type"] = [
        "Closed day" if (w or hd) else "Working day"
        for w, hd in zip(dim_date.is_weekend, dim_date.is_holiday)
    ]

    dim_hour = pd.DataFrame({"hour": range(24)})
    dim_hour["hour_label"] = [f"{x:02d}:00" for x in dim_hour.hour]
    dim_hour["period"] = pd.cut(dim_hour.hour, [-1, 5, 11, 17, 23],
                                labels=["Night", "Morning", "Afternoon", "Evening"])

    summary = pd.DataFrame([{
        "building": job["building"], "rows_in_file": q.rows_in_file,
        "rows_used": q.rows_used, "interval_minutes": q.interval_minutes,
        "coverage_pct": round(q.coverage_pct, 2),
        "duplicates_removed": q.duplicates_removed,
        "total_kwh": round(q.clean_sum, 2), "tariff_eur_kwh": price,
        "timestamp_handling": q.timestamp_mode,
        "checks_passed": f"{len(checks)}/{len(checks)}",
    }])

    out = Path(job.get("out", "out/report.html")).parent / "powerbi"
    out.mkdir(parents=True, exist_ok=True)
    fact.to_csv(out / "fact_readings.csv", index=False)
    dim_date.to_csv(out / "dim_date.csv", index=False)
    dim_hour.to_csv(out / "dim_hour.csv", index=False)
    summary.to_csv(out / "run_summary.csv", index=False)
    (out / "measures.dax").write_text(MEASURES, encoding="utf-8")
    (out / "BUILD.md").write_text(BUILD, encoding="utf-8")

    print(f"  Power BI model written to {out}/")
    print(f"    fact_readings.csv  {len(fact):,} rows")
    print(f"    dim_date.csv       {len(dim_date):,} rows")
    print(f"    dim_hour.csv       24 rows")
    print(f"    measures.dax       {MEASURES.count('=') - MEASURES.count('==')} measures")
    print(f"\n  Cross-check against the PDF report:")
    print(f"    closed kWh   engine {res['closed_kwh']:>14,.2f} | "
          f"model {fact.loc[fact.is_closed,'kwh'].sum():>14,.2f}")
    print(f"    total kWh    engine {res['total_kwh']:>14,.2f} | "
          f"model {fact['kwh'].sum():>14,.2f}")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(__doc__)
        raise SystemExit(2)
    raise SystemExit(run(sys.argv[1]))
