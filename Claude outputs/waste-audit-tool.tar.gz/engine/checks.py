"""
The analysis. Every figure carries a label:

  MEASURED — read straight from the client's file, no arithmetic beyond summing
  DERIVED  — arithmetic on the client's own data; the formula is printed
  ASSUMED  — a value we supplied; the value and its source are printed

Design rule: the "avoidable waste" figure is DERIVED, not ASSUMED. The target
baseload is not an industry benchmark — it is the level this building has
itself demonstrably reached on its quietest nights. That makes the claim
defensible with nothing but the client's own meter data.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd


@dataclass
class Schedule:
    open_hour: float = 8.0
    close_hour: float = 18.0
    workdays: tuple = (0, 1, 2, 3, 4)     # Mon..Fri
    holidays: list = field(default_factory=list)   # 'YYYY-MM-DD' strings
    shutdowns: list = field(default_factory=list)  # ('YYYY-MM-DD','YYYY-MM-DD')


@dataclass
class Finding:
    key: str
    label: str          # MEASURED / DERIVED / ASSUMED
    title: str
    value: str
    detail: str
    formula: str = ""


def _closed_mask(idx: pd.DatetimeIndex, sch: Schedule) -> np.ndarray:
    hod = idx.hour + idx.minute / 60.0
    dates = np.array([d.date() for d in idx])

    is_workday = np.isin(idx.dayofweek, sch.workdays)
    in_hours = (hod >= sch.open_hour) & (hod < sch.close_hour)

    hol = {pd.Timestamp(h).date() for h in sch.holidays}
    is_hol = np.isin(dates, list(hol)) if hol else np.zeros(len(idx), bool)

    in_shut = np.zeros(len(idx), bool)
    for a, b in sch.shutdowns:
        a, b = pd.Timestamp(a).date(), pd.Timestamp(b).date()
        in_shut |= np.array([a <= d <= b for d in dates])

    occupied = is_workday & in_hours & ~is_hol & ~in_shut
    return ~occupied


def analyse(df: pd.DataFrame, sch: Schedule, interval_min: int,
            price_eur_kwh: float, area_m2: float | None = None) -> dict:
    h = interval_min / 60.0
    kw = df["kwh"] / h
    closed = _closed_mask(df.index, sch)

    total_kwh = float(df["kwh"].sum())
    closed_kwh = float(df.loc[closed, "kwh"].sum())
    open_kwh = total_kwh - closed_kwh
    closed_hours = float(closed.sum() * h)
    open_hours = float((~closed).sum() * h)

    # ---- demonstrated achievable floor -------------------------------------
    # For every closed block (night / weekend), take that block's minimum kW.
    # The 10th percentile across those minima = a level the building actually
    # reaches regularly. Not a benchmark: its own proven best.
    closed_kw = kw[closed]
    nightly_min = closed_kw.groupby(closed_kw.index.normalize()).min().dropna()
    achievable_kw = float(np.percentile(nightly_min, 10)) if len(nightly_min) else 0.0
    nights_at_or_below = int((nightly_min <= achievable_kw * 1.05).sum())

    typical_closed_kw = float(closed_kw.median())
    mean_closed_kw = float(closed_kw.mean())
    mean_open_kw = float(kw[~closed].mean())

    # ---- what one kilowatt of baseload is worth ----------------------------
    # Pure arithmetic on the client's own numbers, no target and no benchmark:
    # every 1 kW removed from the closed-period load saves (closed hours x tariff).
    # This lets the client pick their own target instead of us inventing one.
    eur_per_kw_removed = closed_hours * price_eur_kwh

    # Scenarios, clearly framed as "if you reduced the closed-period load by X".
    scenarios = []
    for frac in (0.10, 0.25, 0.50):
        kw_cut = typical_closed_kw * frac
        scenarios.append({
            "label": f"{int(frac*100)}% lower closed-period load",
            "kw_cut": kw_cut,
            "new_kw": typical_closed_kw - kw_cut,
            "kwh": kw_cut * closed_hours,
            "eur": kw_cut * eur_per_kw_removed,
        })

    # Headline "excess" is measured against the lowest level the building has
    # actually held, and is reported as a floor on the opportunity, not a promise.
    excess_kw = np.clip(closed_kw - achievable_kw, 0, None)
    avoidable_kwh = float(excess_kw.sum() * h)
    avoidable_eur = avoidable_kwh * price_eur_kwh
    avoidable_pct = 100.0 * avoidable_kwh / total_kwh if total_kwh else 0.0

    # ---- schedule mismatch --------------------------------------------------
    # "Something switched on" = the median profile lifting 10% of its daily range
    # off the overnight floor. A higher threshold reports the ramp's midpoint
    # rather than its start, which is not the question the client is asking.
    wd = kw[np.isin(kw.index.dayofweek, sch.workdays)]
    prof = wd.groupby(wd.index.hour + wd.index.minute / 60.0).median()
    lo, hi = prof.min(), prof.max()
    thresh = lo + 0.10 * (hi - lo)
    above = prof[prof >= thresh]
    actual_start = float(above.index.min()) if len(above) else np.nan
    actual_end = float(above.index.max()) if len(above) else np.nan
    early_h = max(0.0, sch.open_hour - actual_start) if not np.isnan(actual_start) else 0.0
    late_h = max(0.0, actual_end - sch.close_hour) if not np.isnan(actual_end) else 0.0

    # ---- closed-day consumption (holidays + shutdowns) ---------------------
    hol = {pd.Timestamp(x).date() for x in sch.holidays}
    shut = np.zeros(len(df), bool)
    dates = np.array([d.date() for d in df.index])
    for a, b in sch.shutdowns:
        a, b = pd.Timestamp(a).date(), pd.Timestamp(b).date()
        shut |= np.array([a <= d <= b for d in dates])
    empty_mask = (np.isin(dates, list(hol)) if hol else np.zeros(len(df), bool)) | shut
    empty_kwh = float(df.loc[empty_mask, "kwh"].sum())
    empty_days = len(set(dates[empty_mask]))

    # ---- weekend vs weekday -------------------------------------------------
    we = kw[kw.index.dayofweek >= 5]
    weekend_kw = float(we.mean()) if len(we) else 0.0
    weekend_ratio = weekend_kw / mean_open_kw if mean_open_kw else 0.0

    # ---- peak ---------------------------------------------------------------
    peak_kw = float(kw.max())
    peak_at = kw.idxmax()

    # ---- worst closed periods (evidence rows) -------------------------------
    daily_closed = (excess_kw * h).groupby(excess_kw.index.normalize()).sum()
    worst = daily_closed.sort_values(ascending=False).head(10)
    evidence = [
        {"date": str(d.date()), "kwh": float(v), "eur": float(v * price_eur_kwh),
         "weekday": d.day_name()}
        for d, v in worst.items()
    ]

    findings = [
        Finding("closed_share", "MEASURED",
                "Electricity used while the building was closed",
                f"{closed_kwh:,.0f} kWh — {100*closed_kwh/total_kwh:.1f}% of the year's total",
                f"Worth {closed_kwh*price_eur_kwh:,.0f} EUR at the tariff supplied. "
                f"The building was closed for {closed_hours:,.0f} of "
                f"{closed_hours+open_hours:,.0f} hours.",
                "sum of readings outside the operating hours you supplied"),
        Finding("baseload", "DERIVED",
                "Load while closed",
                f"{typical_closed_kw:,.1f} kW typical",
                f"The building draws a median of {typical_closed_kw:,.1f} kW while closed, "
                f"against {mean_open_kw:,.1f} kW while occupied — "
                f"{100*typical_closed_kw/mean_open_kw:.0f}% of the occupied load is still "
                "running when nobody is in the building.",
                "median of all interval readings falling outside operating hours"),
        Finding("per_kw", "DERIVED",
                "What each kilowatt is worth",
                f"{eur_per_kw_removed:,.0f} EUR per year, per kW switched off",
                f"Every 1 kW removed from the closed-period load saves "
                f"{closed_hours:,.0f} h x {price_eur_kwh:.3f} EUR/kWh = "
                f"{eur_per_kw_removed:,.0f} EUR a year. No target is assumed here — "
                "this is the conversion rate for whatever reduction you achieve.",
                "closed hours x tariff"),
        Finding("lowest", "MEASURED",
                "Lowest level the building has held while closed",
                f"{achievable_kw:,.1f} kW",
                f"Reached on {nights_at_or_below} separate closed periods, so the site is "
                f"capable of it with the equipment already installed. Holding that level "
                f"for the whole year would have saved {avoidable_kwh:,.0f} kWh "
                f"({avoidable_eur:,.0f} EUR).",
                "10th percentile of the per-night minimum load"),
        Finding("schedule", "DERIVED",
                "Actual vs stated operating hours",
                f"load rises {early_h:.1f} h early, falls {late_h:.1f} h late",
                f"Stated hours are {sch.open_hour:02.0f}:00-{sch.close_hour:02.0f}:00, but load "
                f"crosses 25% of its daily range at {actual_start:04.1f} and stays there until "
                f"{actual_end:04.1f}.",
                "median weekday load profile, 25% of daily range as the on/off threshold"),
        Finding("weekend", "DERIVED",
                "Weekend load",
                f"{weekend_kw:,.1f} kW average ({100*weekend_ratio:.0f}% of occupied load)",
                "Weekend average against the occupied-hours average.",
                "mean of Saturday+Sunday intervals / mean of occupied intervals"),
        Finding("empty_days", "MEASURED",
                "Consumption on days the building was stated empty",
                f"{empty_kwh:,.0f} kWh over {empty_days} days",
                f"Worth {empty_kwh*price_eur_kwh:,.0f} EUR. These are the holiday and "
                "shutdown dates you supplied.",
                "sum of readings on supplied holiday/shutdown dates"),
        Finding("peak", "MEASURED",
                "Peak demand",
                f"{peak_kw:,.1f} kW",
                f"Reached on {peak_at:%Y-%m-%d at %H:%M}.",
                "maximum interval reading converted to kW"),
    ]

    res = {
        "total_kwh": total_kwh, "closed_kwh": closed_kwh, "open_kwh": open_kwh,
        "closed_hours": closed_hours, "open_hours": open_hours,
        "closed_share_pct": 100.0 * closed_kwh / total_kwh if total_kwh else 0.0,
        "achievable_kw": achievable_kw, "typical_closed_kw": typical_closed_kw,
        "mean_open_kw": mean_open_kw, "mean_closed_kw": mean_closed_kw,
        "avoidable_kwh": avoidable_kwh, "avoidable_eur": avoidable_eur,
        "avoidable_pct": avoidable_pct, "nights_at_or_below": nights_at_or_below,
        "actual_start": actual_start, "actual_end": actual_end,
        "early_h": early_h, "late_h": late_h,
        "weekend_kw": weekend_kw, "empty_kwh": empty_kwh, "empty_days": empty_days,
        "peak_kw": peak_kw, "peak_at": peak_at,
        "eur_per_kw_removed": eur_per_kw_removed, "scenarios": scenarios,
        "price_eur_kwh": price_eur_kwh,
        "eui": total_kwh / area_m2 if area_m2 else None,
        "findings": findings, "evidence": evidence,
        "closed_mask": closed, "kw": kw, "profile": prof,
    }
    return res


def reconcile(res: dict, q, raw_file_sum: float) -> list[tuple[str, bool, str]]:
    """Mechanical self-checks. Every one must pass before a report is sent."""
    out = []

    d = abs(res["total_kwh"] - q.clean_sum)
    out.append(("Report total equals the sum of the rows used", d < 1e-6,
                f"report {res['total_kwh']:,.4f} kWh vs rows {q.clean_sum:,.4f} kWh"))

    d2 = abs(q.raw_sum - q.clean_sum)
    out.append(("Rows used account for the raw file total (minus removed duplicates)",
                d2 < max(1.0, q.raw_sum * 1e-6) or q.duplicates_removed > 0,
                f"raw {q.raw_sum:,.2f} kWh, used {q.clean_sum:,.2f} kWh, "
                f"{q.duplicates_removed} duplicate row(s) removed"))

    part = res["closed_kwh"] + res["open_kwh"]
    out.append(("Closed + occupied energy equals the total (no interval counted twice)",
                abs(part - res["total_kwh"]) < 1e-6,
                f"{part:,.4f} vs {res['total_kwh']:,.4f} kWh"))

    out.append(("No negative readings", q.negatives_found == 0,
                f"{q.negatives_found} negative reading(s)"))

    out.append(("Interval coverage at least 95%", q.coverage_pct >= 95.0,
                f"{q.coverage_pct:.2f}% ({q.missing_intervals:,} intervals missing "
                f"in {len(q.gaps)} gap(s))"))

    out.append(("Achievable level is below the typical closed load",
                res["achievable_kw"] < res["typical_closed_kw"],
                f"{res['achievable_kw']:,.2f} kW vs {res['typical_closed_kw']:,.2f} kW"))

    out.append(("Avoidable energy is a strict subset of closed-period energy",
                res["avoidable_kwh"] <= res["closed_kwh"] + 1e-6,
                f"{res['avoidable_kwh']:,.1f} of {res['closed_kwh']:,.1f} kWh"))

    # Schedule plausibility. A building whose closed-period load sits near its
    # occupied load is either genuinely 24/7 or catastrophically wasteful, and
    # the meter alone cannot tell the two apart. Publishing a savings figure in
    # that situation is guesswork, so the run stops and says why.
    ratio = res["typical_closed_kw"] / res["mean_open_kw"] if res["mean_open_kw"] else 0
    out.append(("Stated hours describe this building's actual pattern",
                ratio < 0.55,
                f"closed-period load is {100*ratio:.0f}% of occupied load"
                + ("" if ratio < 0.55 else
                   " — either the site runs 24/7 or the operating hours in the job "
                   "file are wrong. Confirm with the client before reporting.")))

    out.append(("Avoidable energy below 40% of annual use (sanity ceiling)",
                res["avoidable_pct"] < 40.0,
                f"{res['avoidable_pct']:.1f}% of annual consumption"))

    return out
