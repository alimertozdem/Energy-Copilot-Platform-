"""
Ingest: read whatever the client actually sent, normalise it, and report on
its quality. Nothing here is allowed to silently change a number.

Rules this module obeys:
  1. Never fill a gap. A missing interval stays missing and is reported.
     (Filling gaps inflates totals and would make the report unverifiable.)
  2. Never drop a row without counting it.
  3. Always return the exact sum of the raw values alongside the clean frame,
     so the report can reconcile back to the file the client sent.
"""
from __future__ import annotations

import csv
import io
import re
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

TS_HINTS = ["timestamp", "zeitstempel", "datetime", "date_time", "time", "zeit",
            "datum", "tarih", "zaman", "interval", "period", "from", "start"]
VAL_HINTS = ["kwh", "verbrauch", "consumption", "value", "energy", "wert",
            "tuketim", "tüketim", "demand", "kw", "reading", "menge"]


@dataclass
class DataQuality:
    rows_in_file: int = 0
    rows_used: int = 0
    duplicates_removed: int = 0
    nulls_removed: int = 0
    negatives_found: int = 0
    interval_minutes: int | None = None
    expected_intervals: int = 0
    missing_intervals: int = 0
    coverage_pct: float = 0.0
    gaps: list = field(default_factory=list)          # [(start, end, n_missing)]
    dst_days: list = field(default_factory=list)
    timestamp_mode: str = "wall-clock local time"
    raw_sum: float = 0.0
    clean_sum: float = 0.0
    first_ts: pd.Timestamp | None = None
    last_ts: pd.Timestamp | None = None


def _sniff(path: str) -> tuple[str, str]:
    """Detect delimiter and decimal mark from the first few KB."""
    with open(path, "r", encoding="utf-8-sig", errors="replace") as f:
        head = f.read(8192)
    try:
        delim = csv.Sniffer().sniff(head, delimiters=",;\t|").delimiter
    except csv.Error:
        delim = max([",", ";", "\t", "|"], key=head.count)
    body = "\n".join(head.splitlines()[1:])
    # decimal comma if commas sit between digits and the delimiter isn't a comma
    dec = ","
    if delim == ",":
        dec = "."
    elif len(re.findall(r"\d,\d", body)) > len(re.findall(r"\d\.\d", body)):
        dec = ","
    else:
        dec = "."
    return delim, dec


def _pick_column(cols: list[str], hints: list[str]) -> str | None:
    low = {c: c.lower().strip() for c in cols}
    for c, l in low.items():
        if any(l == h for h in hints):
            return c
    for c, l in low.items():
        if any(h in l for h in hints):
            return c
    return None


def _check_timezone(tz: str) -> None:
    """Fail early and legibly on an unknown timezone.

    Windows ships no system timezone database, so pandas needs the `tzdata`
    package. Without it every tz_localize raises a 60-line traceback that says
    nothing useful. Caught here instead.
    """
    try:
        import zoneinfo
        zoneinfo.ZoneInfo(tz)
    except ModuleNotFoundError:
        raise RuntimeError(
            "The timezone database is missing. Install it with:\n"
            "    pip install tzdata\n"
            "(Windows has no system timezone database, so this is always needed there.)"
        ) from None
    except Exception:
        raise ValueError(
            f'Unknown timezone "{tz}". Use an IANA name such as "Europe/Berlin", '
            '"Europe/Istanbul" or "US/Eastern".'
        ) from None


def load_meter_csv(
    path: str,
    timezone: str,
    unit: str = "kwh",                 # "kwh" (energy per interval) or "kw" (average power)
    timestamp_col: str | None = None,
    value_col: str | None = None,
) -> tuple[pd.DataFrame, DataQuality]:
    """Return (clean dataframe indexed by tz-aware timestamp with 'kwh', quality)."""
    _check_timezone(timezone)
    delim, dec = _sniff(path)
    df = pd.read_csv(path, sep=delim, decimal=dec, encoding="utf-8-sig",
                     engine="python")
    q = DataQuality(rows_in_file=len(df))

    cols = list(df.columns)
    ts_col = timestamp_col or _pick_column(cols, TS_HINTS)
    v_col = value_col or _pick_column(cols, VAL_HINTS)
    if ts_col is None or v_col is None:
        raise ValueError(
            f"Could not identify columns. Found {cols}. "
            "Pass timestamp_col= and value_col= explicitly."
        )

    # Does the export carry a UTC offset or a 'Z'? Meter exports that span a DST
    # change carry TWO different offsets, which pandas refuses to mix unless we
    # parse through UTC first. Detect, then take the correct branch.
    sample = df[ts_col].astype(str).head(2000)
    has_offset = bool(
        sample.str.contains(r"([+-]\d{2}:?\d{2}|Z)$", regex=True, na=False).any()
    )

    if has_offset:
        # parse everything to UTC (offsets are unambiguous), then present in local time
        ts = pd.to_datetime(df[ts_col], errors="coerce", format="mixed", utc=True)
        ts = ts.dt.tz_convert(timezone)
    else:
        ts = pd.to_datetime(df[ts_col], errors="coerce", format="mixed")
        if getattr(ts.dt, "tz", None) is not None:
            ts = ts.dt.tz_convert(timezone)
        else:
            # Naive stamps come in two kinds and they must NOT be treated alike:
            #
            #  (a) wall-clock local time — the spring-forward hour is absent and
            #      the autumn hour appears twice, exactly as a clock behaves.
            #  (b) a continuous series in fixed local standard time, with no DST
            #      shifts at all. Many metering exports and research datasets
            #      look like this.
            #
            # Forcing (b) into a DST zone shifts the "nonexistent" hour forward
            # onto the next real one, which then looks like a duplicate and gets
            # deleted — silently destroying a real reading. So: detect first.
            probe = ts.dropna()
            try:
                probe.dt.tz_localize(timezone, ambiguous="raise",
                                     nonexistent="raise")
                kind = "wallclock"
            except Exception:
                kind = "standard"

            if kind == "wallclock":
                ts = ts.dt.tz_localize(timezone, ambiguous="infer",
                                       nonexistent="shift_forward")
            else:
                # Pin to the zone's winter (standard-time) offset and keep the
                # series continuous. No reading is moved, merged or dropped.
                import datetime as _dt
                import zoneinfo
                z = zoneinfo.ZoneInfo(timezone)
                jan = _dt.datetime(int(probe.iloc[0].year), 1, 15, 12)
                offset = z.utcoffset(jan)
                ts = ts.dt.tz_localize(_dt.timezone(offset))
                q.timestamp_mode = (
                    f"no DST shifts found in the file — timestamps read as fixed "
                    f"local standard time (UTC{offset.total_seconds()/3600:+.0f}), "
                    "continuous, nothing moved or merged"
                )

    vals = pd.to_numeric(
        df[v_col].astype(str).str.replace(" ", "", regex=False)
        if df[v_col].dtype == object else df[v_col],
        errors="coerce",
    )

    work = pd.DataFrame({"timestamp": ts, "value": vals})
    q.nulls_removed = int(work["timestamp"].isna().sum() | 0) + int(work["value"].isna().sum())
    work = work.dropna()
    q.raw_sum = float(work["value"].sum())

    before = len(work)
    work = work.drop_duplicates(subset="timestamp", keep="first")
    q.duplicates_removed = before - len(work)

    q.negatives_found = int((work["value"] < 0).sum())

    work = work.sort_values("timestamp").set_index("timestamp")

    # infer interval from the modal gap
    deltas = work.index.to_series().diff().dropna()
    if len(deltas) == 0:
        raise ValueError("Not enough rows to infer an interval.")
    step = deltas.mode().iloc[0]
    q.interval_minutes = int(step.total_seconds() // 60)
    hours = q.interval_minutes / 60.0

    if unit.lower() == "kw":
        work["kwh"] = work["value"] * hours
    else:
        work["kwh"] = work["value"]

    q.first_ts, q.last_ts = work.index[0], work.index[-1]
    q.rows_used = len(work)
    q.clean_sum = float(work["kwh"].sum())

    # coverage against a complete calendar of the same interval
    full = pd.date_range(q.first_ts, q.last_ts, freq=f"{q.interval_minutes}min",
                         tz=work.index.tz)
    q.expected_intervals = len(full)
    missing = full.difference(work.index)
    q.missing_intervals = len(missing)
    q.coverage_pct = 100.0 * q.rows_used / q.expected_intervals if q.expected_intervals else 0.0

    # group missing stamps into contiguous gaps
    if len(missing):
        m = pd.Series(missing)
        brk = m.diff() > step
        gid = brk.cumsum()
        for _, grp in m.groupby(gid):
            q.gaps.append((grp.iloc[0], grp.iloc[-1] + step, len(grp)))
        q.gaps.sort(key=lambda g: g[2], reverse=True)

    # DST transition days (23h / 25h local days) — flagged, not "fixed"
    per_day = work.groupby(work.index.date).size()
    nominal = int(24 * 60 / q.interval_minutes)
    odd = per_day[(per_day != nominal) & (per_day > nominal * 0.5)]
    for d, n in odd.items():
        if n in (nominal - 4, nominal + 4, nominal - int(60 / q.interval_minutes),
                 nominal + int(60 / q.interval_minutes)):
            q.dst_days.append((str(d), int(n)))

    return work[["kwh"]], q
