"""
Report rendering: two charts + a single self-contained HTML file.

The HTML embeds its images as data URIs so the client receives ONE file that
opens anywhere and prints to PDF without a network connection.
"""
from __future__ import annotations

import base64
import html
import io

import matplotlib
matplotlib.use("Agg")
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap

# validated palette (see dataviz reference palette, light mode)
C_WEEKDAY = "#2a78d6"
C_WEEKEND = "#eb6834"
INK = "#0b0b0b"
INK2 = "#52514e"
MUTED = "#8a8984"
GRID = "#e6e5e0"
SURFACE = "#ffffff"
SEQ = ["#cde2fb", "#9ec5f4", "#6da7ec", "#3987e5", "#256abf", "#184f95", "#0d366b"]
SEQ_CMAP = LinearSegmentedColormap.from_list("seq_blue", SEQ)

plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 9,
    "axes.edgecolor": GRID, "axes.labelcolor": INK2, "text.color": INK,
    "xtick.color": INK2, "ytick.color": INK2,
    "axes.spines.top": False, "axes.spines.right": False,
    "figure.facecolor": SURFACE, "axes.facecolor": SURFACE,
})


def _png(fig) -> str:
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=170, bbox_inches="tight",
                facecolor=SURFACE)
    plt.close(fig)
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()


def chart_profile(res: dict, sch) -> str:
    """Median load through the day: working days vs closed days."""
    kw = res["kw"]
    tod = kw.index.hour + kw.index.minute / 60.0

    is_wd = np.isin(kw.index.dayofweek, sch.workdays)
    hol = {pd.Timestamp(x).date() for x in sch.holidays}
    is_hol = np.isin(np.array([d.date() for d in kw.index]), list(hol)) if hol else np.zeros(len(kw), bool)
    work = is_wd & ~is_hol

    p_work = pd.Series(kw.values[work]).groupby(tod[work]).median()
    p_off = pd.Series(kw.values[~work]).groupby(tod[~work]).median()

    fig, ax = plt.subplots(figsize=(9, 3.9))

    floor = res["achievable_kw"]
    ax.axhspan(0, floor, color=GRID, alpha=0.55, lw=0, zorder=0)
    ax.text(0.12, floor * 0.48, f"lowest level this building has held  {floor:,.0f} kW",
            fontsize=7.5, color=MUTED, va="center", zorder=1)

    ax.plot(p_work.index, p_work.values, color=C_WEEKDAY, lw=2, zorder=4)
    ax.plot(p_off.index, p_off.values, color=C_WEEKEND, lw=2, zorder=3)

    # stated opening hours as one band with a single centred label, so nothing
    # has to be squeezed against the series lines
    top = max(p_work.max(), p_off.max()) * 1.18
    for x in (sch.open_hour, sch.close_hour):
        ax.axvline(x, color=MUTED, lw=1, ls=(0, (4, 3)), zorder=2)
    ax.text((sch.open_hour + sch.close_hour) / 2, top * 0.955,
            f"stated opening hours  {int(sch.open_hour):02d}:00–{int(sch.close_hour):02d}:00",
            fontsize=7.5, color=MUTED, ha="center", va="top")

    # actual ramp start
    a = res["actual_start"]
    if not np.isnan(a):
        ax.annotate(
            f"load rises here\n{int(a):02d}:{int((a % 1) * 60):02d}",
            xy=(a, float(p_work.reindex([a]).iloc[0]) if a in p_work.index else p_work.min()),
            xytext=(max(a - 3.6, 0.2), p_work.max() * 0.62),
            fontsize=7.5, color=INK2,
            arrowprops=dict(arrowstyle="-", color=MUTED, lw=1))

    # Direct labels instead of a legend box (2 series). Both are placed at midday,
    # the one x-position where the two series are guaranteed to be far apart —
    # they converge overnight, so a label there would sit on the wrong line.
    mid = 12.0
    y_work = float(p_work.iloc[(np.abs(p_work.index - mid)).argmin()])
    y_off = float(p_off.iloc[(np.abs(p_off.index - mid)).argmin()])
    ax.text(mid, y_work + top * 0.045, "working days", color=C_WEEKDAY,
            fontsize=8.5, ha="center", va="bottom", fontweight="bold")
    ax.text(mid, y_off + top * 0.035, "closed days", color=C_WEEKEND,
            fontsize=8.5, ha="center", va="bottom", fontweight="bold")

    ax.set_xlim(0, 24)
    ax.set_ylim(0, top)
    ax.set_xticks(range(0, 25, 3))
    ax.set_xticklabels([f"{h:02d}:00" for h in range(0, 25, 3)])
    ax.set_ylabel("kW (median)")
    ax.grid(axis="y", color=GRID, lw=0.8)
    ax.set_axisbelow(True)
    return _png(fig)


def chart_carpet(res: dict) -> str:
    """Every hour of the year as one cell. The overnight band is the story."""
    kw = res["kw"]
    hourly = kw.resample("1h").mean()
    frame = pd.DataFrame({
        "d": hourly.index.normalize(), "h": hourly.index.hour, "kw": hourly.values
    })
    grid = frame.pivot_table(index="h", columns="d", values="kw", aggfunc="mean")

    fig, ax = plt.subplots(figsize=(9, 3.4))
    vmax = float(np.nanpercentile(grid.values, 99))
    im = ax.imshow(grid.values, aspect="auto", origin="lower", cmap=SEQ_CMAP,
                   vmin=0, vmax=vmax, interpolation="nearest",
                   extent=[mdates.date2num(grid.columns[0]),
                           mdates.date2num(grid.columns[-1]), 0, 24])
    ax.xaxis_date()
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%b"))
    ax.xaxis.set_major_locator(mdates.MonthLocator())
    ax.set_yticks([0, 6, 12, 18, 24])
    ax.set_yticklabels(["00:00", "06:00", "12:00", "18:00", "24:00"])
    ax.set_ylabel("time of day")
    for s in ax.spines.values():
        s.set_visible(False)
    cb = fig.colorbar(im, ax=ax, pad=0.015, fraction=0.028)
    cb.set_label("kW", color=INK2, fontsize=8)
    cb.outline.set_visible(False)
    cb.ax.tick_params(labelsize=7.5, color=GRID)
    return _png(fig)


CSS = """
:root{
 --ink:#14140f; --ink2:#55544c; --muted:#8e8d83; --line:#e5e4dd; --hair:#f0efe9;
 --bg:#fff; --wash:#f8f7f3; --accent:#1d5fa8; --accent-soft:#eaf1fa;
 --warm:#c2521f; --good:#1a6b4a;
 --serif:"Iowan Old Style","Palatino Linotype",Palatino,Georgia,serif;
 --sans:-apple-system,BlinkMacSystemFont,"Segoe UI",Inter,Roboto,Helvetica,sans-serif;
}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.6 var(--sans);
-webkit-font-smoothing:antialiased}
.page{max-width:780px;margin:0 auto;padding:56px 32px 80px}

/* masthead */
.mast{display:flex;justify-content:space-between;align-items:flex-start;
gap:24px;padding-bottom:18px;border-bottom:2px solid var(--ink)}
.mast .who{font-size:12px;letter-spacing:.14em;text-transform:uppercase;
color:var(--muted);font-weight:600}
h1{font:600 31px/1.15 var(--serif);margin:26px 0 10px;letter-spacing:-.01em}
.sub{color:var(--ink2);margin:0 0 40px;font-size:15px}
.sub b{color:var(--ink);font-weight:600}

/* the one number */
.hero{background:var(--wash);border-radius:14px;padding:32px 34px;margin:0 0 12px;
border:1px solid var(--line)}
.hero .lede{font-size:13px;letter-spacing:.1em;text-transform:uppercase;
color:var(--muted);font-weight:600;margin:0 0 12px}
.hero .n{font:600 46px/1 var(--serif);letter-spacing:-.02em;color:var(--ink)}
.hero .eq{font-size:22px;color:var(--ink2);font-weight:500;font-family:var(--serif)}
.hero p{margin:16px 0 0;color:var(--ink2);font-size:15.5px;max-width:56ch}
.hero strong{color:var(--ink);font-weight:650}

/* three stat cards */
.cards{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin:14px 0 0}
.card{border:1px solid var(--line);border-radius:12px;padding:19px 20px;
background:#fff;display:flex;flex-direction:column}
.card .k{font-size:11.5px;letter-spacing:.09em;text-transform:uppercase;
color:var(--muted);font-weight:650;margin-bottom:11px;line-height:1.35}
.card .v{font:600 26px/1.1 var(--serif);letter-spacing:-.01em;margin-bottom:8px}
.card .v small{font-size:15px;color:var(--ink2);font-weight:500}
.card .d{font-size:13px;color:var(--ink2);line-height:1.5;margin:0}

h2{font:600 13px/1.4 var(--sans);text-transform:uppercase;letter-spacing:.13em;
color:var(--muted);margin:52px 0 8px}
.h2sub{font:500 20px/1.4 var(--serif);color:var(--ink);margin:0 0 18px;max-width:60ch}

figure{margin:0}
img{width:100%;display:block;border-radius:10px;border:1px solid var(--hair)}
figcaption{color:var(--ink2);font-size:13.5px;margin:12px 2px 0;line-height:1.55}

/* where to look */
.look{display:flex;gap:16px;padding:19px 0;border-top:1px solid var(--line)}
.look:last-of-type{border-bottom:1px solid var(--line)}
.look .n{flex:0 0 27px;height:27px;border-radius:50%;background:var(--accent-soft);
color:var(--accent);font-size:13px;font-weight:700;display:flex;
align-items:center;justify-content:center;margin-top:2px}
.look .t{font-weight:650;margin:2px 0 5px;font-size:15.5px}
.look .b{color:var(--ink2);font-size:14.5px;margin:0;line-height:1.6}

table{width:100%;border-collapse:collapse;font-size:14.5px;margin-top:4px}
th{text-align:left;font-size:11px;text-transform:uppercase;letter-spacing:.08em;
color:var(--muted);font-weight:650;padding:9px 10px;border-bottom:1.5px solid var(--ink)}
td{padding:11px 10px;border-bottom:1px solid var(--hair);
font-variant-numeric:tabular-nums}
tr:last-child td{border-bottom:1.5px solid var(--line)}
td.r,th.r{text-align:right}
td.big{font-weight:650}

.note{background:var(--wash);border-radius:10px;padding:16px 19px;font-size:13.5px;
color:var(--ink2);margin-top:16px;line-height:1.6;border:1px solid var(--hair)}

/* appendix */
.f{border-top:1px solid var(--hair);padding:15px 0}
.ftop{display:flex;justify-content:space-between;align-items:baseline;gap:16px}
.ft{font-weight:600;font-size:14.5px}
.fv{font-variant-numeric:tabular-nums;font-weight:650;white-space:nowrap;font-size:14.5px}
.fd{color:var(--ink2);margin:5px 0 0;font-size:13.5px}
.fm{color:var(--muted);font-size:12px;margin:5px 0 0;font-style:italic}
.tag{display:inline-block;font-size:9.5px;letter-spacing:.07em;font-weight:700;
padding:2px 6px;border-radius:3px;vertical-align:2px;margin-right:7px}
.MEASURED{background:var(--accent-soft);color:#134a86}
.DERIVED{background:#e7f4ee;color:var(--good)}
.ASSUMED{background:#fbeee7;color:var(--warm)}
.chk{display:flex;gap:11px;padding:8px 0;font-size:13px;align-items:baseline;
border-bottom:1px solid var(--hair)}
.ok{color:var(--good);font-weight:700;font-size:11px;letter-spacing:.06em}
.bad{color:#b3261e;font-weight:700;font-size:11px}
.chk .d{color:var(--muted);margin-left:auto;font-variant-numeric:tabular-nums;
text-align:right;font-size:12px}
details{margin-top:56px;border-top:2px solid var(--ink);padding-top:20px}
summary{cursor:pointer;font:600 13px/1.4 var(--sans);text-transform:uppercase;
letter-spacing:.13em;color:var(--muted)}
details[open] summary{margin-bottom:8px}
footer{margin-top:48px;padding-top:20px;border-top:1px solid var(--line);
color:var(--muted);font-size:12.5px;line-height:1.65}

@media (max-width:620px){.cards{grid-template-columns:1fr}.page{padding:32px 18px 56px}
h1{font-size:26px}.hero .n{font-size:36px}}
@media print{.page{padding:0;max-width:100%}details{display:block}summary{display:none}
.card,.hero{break-inside:avoid}figure{break-inside:avoid}}
"""


def render(res: dict, q, checks, meta: dict) -> str:
    e = html.escape
    sch = meta['schedule']
    sc = "".join(
        f'<tr><td>{e(s["label"])}</td>'
        f'<td class="r">{s["new_kw"]:,.1f} kW</td>'
        f'<td class="r">{s["kwh"]:,.0f}</td>'
        f'<td class="r">{s["eur"]:,.0f}</td></tr>'
        for s in res["scenarios"]
    )

    ev = "".join(
        f'<tr><td>{e(r["date"])}</td><td>{e(r["weekday"])}</td>'
        f'<td class="r">{r["kwh"]:,.0f}</td><td class="r">{r["eur"]:,.0f}</td></tr>'
        for r in res["evidence"]
    )

    ck = "".join(
        f'<div class="chk"><span class="{"ok" if ok else "bad"}">'
        f'{"PASS" if ok else "FAIL"}</span><span>{e(n)}</span>'
        f'<span class="d">{e(d)}</span></div>'
        for n, ok, d in checks
    )

    gaps = "".join(
        f'<tr><td>{g[0]:%Y-%m-%d %H:%M}</td><td>{g[1]:%Y-%m-%d %H:%M}</td>'
        f'<td class="r">{g[2]:,}</td></tr>' for g in q.gaps[:8]
    ) or '<tr><td colspan="3">No gaps found.</td></tr>'

    # Three findings lead; the rest move to the appendix.
    lead_keys = ("closed_share", "baseload", "per_kw")
    lead = [f for f in res["findings"] if f.key in lead_keys]
    rest = [f for f in res["findings"] if f.key not in lead_keys]

    def block(fs):
        return "".join(
            f'<div class="f"><div class="ftop"><div class="ft">'
            f'<span class="tag {f.label}">{f.label}</span>{e(f.title)}</div>'
            f'<div class="fv">{e(f.value)}</div></div>'
            f'<p class="fd">{e(f.detail)}</p>'
            + (f'<p class="fm">how: {e(f.formula)}</p>' if f.formula else "")
            + "</div>" for f in fs)

    # "Where to look first" — built from what this building's data actually shows.
    # These are places to check, not engineering conclusions.
    looks = []
    if res["early_h"] >= 0.5:
        looks.append((
            f"The time programme that starts the plant",
            f"Load lifts off its overnight level at {res['actual_start']:04.1f}, "
            f"{res['early_h']:.1f} hours before the {sch.open_hour:02.0f}:00 you gave us. "
            "In a BMS this is usually the air-handling start step or an optimum-start "
            "setting that has been widened and never narrowed again."))
    if res["late_h"] >= 0.5:
        looks.append((
            "The off step, and who is in the building after hours",
            f"Load stays up until {res['actual_end']:04.1f}, {res['late_h']:.1f} hours past "
            f"{sch.close_hour:02.0f}:00. Cleaning rounds and a late 'off' step are the two "
            "usual causes, and they are told apart by asking the cleaning contractor "
            "what time they finish."))
    if res["weekend_kw"] > 0.45 * res["mean_open_kw"]:
        looks.append((
            "The weekend and holiday calendar in the BMS",
            f"Closed days average {res['weekend_kw']:,.0f} kW against "
            f"{res['mean_open_kw']:,.0f} kW when occupied. When the closed-day line in the "
            "chart above has the shape of a working day, the weekday schedule is running "
            "seven days a week — either the calendar was never set, or someone put the "
            "system into permanent occupied mode and left it."))
    looks.append((
        "What is actually drawing the overnight load",
        f"Something holds {res['typical_closed_kw']:,.0f} kW through the night. This report "
        "can say how much and when, not what. Server and comms rooms, lifts, external and "
        "car-park lighting, refrigeration and car-park ventilation are where it usually "
        "sits. A week with a clamp meter on the main sub-circuits settles it."))
    if res["empty_kwh"] > 0:
        looks.append((
            "The days the building was supposed to be empty",
            f"{res['empty_kwh']:,.0f} kWh ({res['empty_kwh']*res['price_eur_kwh']:,.0f} EUR) "
            f"was used across the {res['empty_days']} closed dates you listed. Those dates "
            "are the cheapest place to test a change, because nothing that happens on them "
            "can inconvenience anyone."))

    look_html = "".join(
        f'<div class="look"><div class="n">{i}</div><div><p class="t">{e(t)}</p>'
        f'<p class="b">{e(b)}</p></div></div>'
        for i, (t, b) in enumerate(looks, 1))

    # Plain-language stat cards. No jargon on the first page — the MEASURED /
    # DERIVED tags live in the appendix, where a technical reader will look.
    by_key = {f.key: f for f in res["findings"]}
    cards = [
        ("Load while the building is closed",
         f"{res['typical_closed_kw']:,.0f} <small>kW</small>",
         f"Against {res['mean_open_kw']:,.0f} kW when people are in. "
         f"{100*res['typical_closed_kw']/res['mean_open_kw']:.0f}% of the working-day "
         "load is still running with nobody there."),
        ("What one kilowatt is worth",
         f"{res['eur_per_kw_removed']:,.0f} <small>EUR/yr</small>",
         f"Switch off 1 kW outside working hours and it saves this much every year. "
         "Ten kilowatts is ten times it."),
        ("Lowest this site has held",
         f"{res['achievable_kw']:,.0f} <small>kW</small>",
         f"Reached on {res['nights_at_or_below']} separate nights, so the equipment "
         "already installed can do it."),
    ]
    card_html = "".join(
        f'<div class="card"><div class="k">{e(k)}</div>'
        f'<div class="v">{v}</div><p class="d">{e(d)}</p></div>'
        for k, v, d in cards)

    def block(fs):
        return "".join(
            f'<div class="f"><div class="ftop"><div class="ft">'
            f'<span class="tag {f.label}">{f.label}</span>{e(f.title)}</div>'
            f'<div class="fv">{e(f.value)}</div></div>'
            f'<p class="fd">{e(f.detail)}</p>'
            + (f'<p class="fm">how: {e(f.formula)}</p>' if f.formula else "")
            + "</div>" for f in fs)

    # "Where to look first" — built from what this building's data actually shows.
    looks = []
    if res["early_h"] >= 0.5:
        looks.append((
            "The time programme that starts the plant",
            f"Load lifts off its overnight level at {res['actual_start']:04.1f}, "
            f"{res['early_h']:.1f} hours before the {sch.open_hour:02.0f}:00 you gave us. "
            "In a building management system this is usually the air-handling start "
            "step, or an optimum-start setting that was widened one cold winter and "
            "never narrowed again."))
    if res["late_h"] >= 0.5:
        looks.append((
            "The off step, and who is in the building after hours",
            f"Load stays up until {res['actual_end']:04.1f}, {res['late_h']:.1f} hours past "
            f"{sch.close_hour:02.0f}:00. Cleaning rounds and a late off step are the two "
            "usual causes, and one phone call to the cleaning contractor tells you which."))
    if res["weekend_kw"] > 0.45 * res["mean_open_kw"]:
        looks.append((
            "The weekend and holiday calendar",
            f"Closed days average {res['weekend_kw']:,.0f} kW against "
            f"{res['mean_open_kw']:,.0f} kW when occupied. Where the closed-day line in "
            "the chart above has the shape of a working day, the weekday schedule is "
            "running seven days a week — either the calendar was never set up, or "
            "somebody put the system into permanent occupied mode and left it there."))
    looks.append((
        "What is actually drawing the overnight load",
        f"Something holds {res['typical_closed_kw']:,.0f} kW through the night. This "
        "report can say how much and when, not what. Server and comms rooms, lifts, "
        "external and car-park lighting, refrigeration and car-park ventilation are "
        "where it usually sits. A week with a clamp meter on the main sub-circuits "
        "settles it for good."))
    if res["empty_kwh"] > 0:
        looks.append((
            "The days the building was supposed to be empty",
            f"{res['empty_kwh']:,.0f} kWh ({res['empty_kwh']*res['price_eur_kwh']:,.0f} EUR) "
            f"was used across the {res['empty_days']} closed dates you listed. Those are "
            "the cheapest days to trial a change, because nothing that happens on them "
            "can inconvenience anybody."))

    look_html = "".join(
        f'<div class="look"><div class="n">{i}</div><div><p class="t">{e(t)}</p>'
        f'<p class="b">{e(b)}</p></div></div>'
        for i, (t, b) in enumerate(looks, 1))

    weekend_line = ""
    if res["weekend_kw"] > 0.45 * res["mean_open_kw"]:
        weekend_line = (" The closed-day line holding the shape of a working day is the "
                        "single clearest sign that the schedule, not the equipment, is "
                        "the problem.")

    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Out-of-hours energy review — {e(meta['building'])}</title>
<style>{CSS}</style></head><body><div class="page">

<div class="mast">
  <div class="who">Out-of-hours energy review</div>
  <div class="who">{q.first_ts:%b %Y} &ndash; {q.last_ts:%b %Y}</div>
</div>

<h1>{e(meta['building'])}</h1>
<p class="sub">Prepared for <b>{e(meta['client'])}</b> from
{q.rows_used:,} meter readings at {q.interval_minutes}-minute intervals,
{q.coverage_pct:.1f}% of the period covered.</p>

<div class="hero">
  <p class="lede">Electricity used while the building was closed</p>
  <div class="n">{res['closed_kwh']:,.0f} <span class="eq">kWh &nbsp;=&nbsp;
  {res['closed_kwh']*res['price_eur_kwh']:,.0f} EUR</span></div>
  <p>That is <strong>{res['closed_share_pct']:.0f}% of everything this site bought
  last year</strong>, used outside the hours you told us the building is in use.
  Not all of it is waste &mdash; some equipment has to run. The question this
  report answers is how much has to, and how you would find out.</p>
</div>

<div class="cards">{card_html}</div>

<h2>The day, hour by hour</h2>
<p class="h2sub">Both lines sit at the same level all night. The building does not
switch off &mdash; it turns up.{weekend_line}</p>
<figure>
  <img src="{chart_profile(res, meta['schedule'])}" alt="Median load by time of day">
  <figcaption>Median load at each time of day across the whole period, working days
  against closed days. The shaded band is the lowest level the site has actually
  held while closed &mdash; everything above it is load that was switched on.</figcaption>
</figure>

<h2>Where to look first</h2>
<p class="h2sub">Five places, in the order a facilities team would check them.</p>
{look_html}
<div class="note">These are places to check, not conclusions. This review reads the
meter; it has not seen your plant. Each item names what the data shows and the usual
cause, so whoever knows the building can confirm or rule it out in an afternoon.</div>

<h2>What a reduction is worth</h2>
<p class="h2sub">You pick the target. This converts it into money.</p>
<table><thead><tr><th>If closed-period load fell by</th><th class="r">new level</th>
<th class="r">kWh saved a year</th><th class="r">EUR saved a year</th></tr></thead>
<tbody>{sc}</tbody></table>
<div class="note">Arithmetic on your own meter data: kW reduction &times;
{res['closed_hours']:,.0f} closed hours &times; {res['price_eur_kwh']:.3f} EUR/kWh.
This is not a prediction of what any particular measure would achieve &mdash; it
converts a reduction you choose into the money it is worth.</div>

<h2>Every hour of the period</h2>
<p class="h2sub">One cell per hour. The dark band that never fades is the load that
never goes away.</p>
<figure>
  <img src="{chart_carpet(res)}" alt="Load carpet plot">
  <figcaption>White means no reading was received. The pale vertical stripes are
  weekends. Read the picture bottom to top as one day, left to right as the year.</figcaption>
</figure>

<details open>
<summary>Appendix &mdash; every measurement, and how this report was checked</summary>

{block(res["findings"])}

<h2>Highest out-of-hours days</h2>
<table><thead><tr><th>Date</th><th>Day</th><th class="r">kWh above the site's
own lowest level</th><th class="r">EUR</th></tr></thead><tbody>{ev}</tbody></table>

<h2>Checks run before this report was issued</h2>
{ck}
<div class="note">These run automatically every time the report is produced, and each
one compares the report back to the file you sent. If any had failed you would not be
reading this. The accompanying workbook lets you re-derive every headline number in
Excel yourself, from your own readings, without taking anything here on trust.</div>

<h2>Data received</h2>
<table><tbody>
<tr><td>Rows in file</td><td class="r">{q.rows_in_file:,}</td></tr>
<tr><td>Rows used</td><td class="r">{q.rows_used:,}</td></tr>
<tr><td>Reading interval</td><td class="r">{q.interval_minutes} minutes</td></tr>
<tr><td>Coverage of the period</td><td class="r">{q.coverage_pct:.2f}%</td></tr>
<tr><td>Duplicate timestamps removed</td><td class="r">{q.duplicates_removed:,}</td></tr>
<tr><td>Total energy in file</td><td class="r big">{q.clean_sum:,.1f} kWh</td></tr>
<tr><td>Timestamps</td><td class="r">{e(q.timestamp_mode)}</td></tr>
<tr><td>Tariff used</td><td class="r">{res['price_eur_kwh']:.3f} EUR/kWh (supplied by you)</td></tr>
</tbody></table>

<h2>Gaps in the data</h2>
<table><thead><tr><th>From</th><th>To</th><th class="r">intervals missing</th></tr>
</thead><tbody>{gaps}</tbody></table>
<div class="note">Missing intervals are left missing. They are never estimated or
filled in, because filling them would change your totals.</div>
</details>

<footer>
Prepared by {e(meta['author'])}. Figures marked MEASURED come straight from the file
you supplied; DERIVED figures are arithmetic on it, with the formula shown beside each
one. This review reports what the meter data shows. It is not an engineering survey
and does not certify compliance with any standard.
</footer>
</div></body></html>"""


def render_teaser(res: dict, q, meta: dict) -> str:
    """The free sample. One page.

    It proves two things and nothing more: that the data was read correctly, and
    that there is money sitting outside working hours. It deliberately does NOT
    contain the diagnosis — no 'where to look', no scenario table, no evidence
    days, no appendix, no verification workbook. Those are the paid report.
    """
    e = html.escape
    sch = meta["schedule"]
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Out-of-hours snapshot — {e(meta['building'])}</title>
<style>{CSS}
.gate{{border:1px solid var(--line);border-radius:12px;padding:22px 24px;
margin-top:30px;background:#fff}}
.gate h3{{font:600 17px/1.35 var(--serif);margin:0 0 10px}}
.gate ul{{margin:0;padding-left:20px;color:var(--ink2);font-size:14.5px}}
.gate li{{margin-bottom:7px}}
.gate p{{margin:14px 0 0;font-size:14.5px;color:var(--ink2)}}
.stamp{{display:inline-block;font-size:11px;letter-spacing:.12em;text-transform:uppercase;
font-weight:700;color:var(--accent);background:var(--accent-soft);
padding:5px 11px;border-radius:20px}}
</style></head><body><div class="page">

<div class="mast">
  <div class="who">Out-of-hours snapshot</div>
  <div class="who">{q.first_ts:%b %Y} &ndash; {q.last_ts:%b %Y}</div>
</div>

<h1>{e(meta['building'])}</h1>
<p class="sub"><span class="stamp">Free sample</span><br><br>
Read from the {q.rows_used:,} meter readings you sent, at {q.interval_minutes}-minute
intervals, covering {q.coverage_pct:.1f}% of the period. Your file totals
<b>{q.clean_sum:,.0f} kWh</b> &mdash; open it in Excel, sum the column, and you will
get the same number.</p>

<div class="hero">
  <p class="lede">Electricity used while the building was closed</p>
  <div class="n">{res['closed_kwh']:,.0f} <span class="eq">kWh &nbsp;=&nbsp;
  {res['closed_kwh']*res['price_eur_kwh']:,.0f} EUR</span></div>
  <p>Across {res['closed_hours']:,.0f} hours outside
  {sch.open_hour:02.0f}:00&ndash;{sch.close_hour:02.0f}:00 &mdash;
  <strong>{res['closed_share_pct']:.0f}% of everything the site bought</strong>.
  While closed the building holds <strong>{res['typical_closed_kw']:,.0f} kW</strong>
  against {res['mean_open_kw']:,.0f} kW when occupied. Every 1 kW switched off out of
  hours is worth <strong>{res['eur_per_kw_removed']:,.0f} EUR a year</strong> at your
  own tariff.</p>
</div>

<h2>The day, hour by hour</h2>
<figure>
  <img src="{chart_profile(res, sch)}" alt="Median load by time of day">
  <figcaption>Median load at each time of day, working days against closed days.
  The shaded band is the lowest level your site has actually held while closed.</figcaption>
</figure>

<div class="gate">
  <h3>What the full review adds</h3>
  <ul>
    <li><b>Where to look first</b> &mdash; the specific schedule, calendar and
    circuit questions this profile raises, in the order a facilities team would
    work through them</li>
    <li><b>What a reduction is worth</b> &mdash; your own figures converted into
    money at three levels of ambition</li>
    <li><b>The worst days of the year</b>, dated, so a change can be trialled where
    it costs nothing to get wrong</li>
    <li><b>Every measurement</b> with its formula printed beside it, plus the nine
    reconciliation checks the report is not issued without</li>
    <li><b>An Excel workbook</b> that re-derives every headline number from your raw
    readings with ordinary spreadsheet formulas, so your own team can verify it
    without taking a word of it on trust</li>
  </ul>
  <p>No site visit, no access to your systems. Reply and I will send the scope and
  the fee.</p>
</div>

<footer>
Prepared by {e(meta['author'])} from the interval data you supplied. Every figure on
this page is a sum, a median or a product of your own readings &mdash; nothing is
modelled, estimated or benchmarked. This is not an engineering survey and does not
certify compliance with any standard.
</footer>
</div></body></html>"""
